/* eslint-disable testing-library/no-render-in-setup */
import React from 'react';
import { render, screen, fireEvent } from '@testing-library/react';
import Dashboard from '../components/dashboard.component';

describe('Dashboard', () => {
  const data = {
    allUsers: [
      {
        fullname: 'John Doe',
        email: 'john@example.com',
        phone: '1234567890',
        primaryDropOffPerson: 'Jane Doe',
        children: '[{"childName": "Child 1", "childAge": 5, "dropoffSchedule": []}]',
        alternateContacts: '[]',
      },
    ],
  };

  const setToken = jest.fn();

  beforeEach(() => {
    render(<Dashboard data={data} setToken={setToken} />);
  });

  test('renders the dashboard', () => {
    expect(screen.getByText('All Registered Parents')).toBeInTheDocument();
  });

  test('displays user information', () => {
    expect(screen.getByText('John Doe')).toBeInTheDocument();
    expect(screen.getByText('john@example.com')).toBeInTheDocument();
    expect(screen.getByText('1234567890')).toBeInTheDocument();
    expect(screen.getByText('Jane Doe')).toBeInTheDocument();
  });

  test('allows editing name', () => {
    fireEvent.click(screen.getByText('Edit'));

    const nameInput = screen.getByDisplayValue('John Doe');
    fireEvent.change(nameInput, { target: { value: 'John Smith' } });
    expect(nameInput.value).toBe('John Smith');
  });
  // test to allow editing email
    test('allows editing email', () => {
        fireEvent.click(screen.getByText('Edit'));
    
        const emailInput = screen.getByDisplayValue('john@example.com');
        fireEvent.change(emailInput, { target: { value: 'jaime@example.ca' } });
        expect(emailInput.value).toBe('jaime@example.ca');
    });
    // test to allow editing phone
    test('allows editing phone', () => {
        fireEvent.click(screen.getByText('Edit'));
    
        const phoneInput = screen.getByDisplayValue('1234567890');
        fireEvent.change(phoneInput, { target: { value: '0987654321' } });
        expect(phoneInput.value).toBe('0987654321');
    });
    // test to allow editing primary drop off person
    test('allows editing primary drop off person', () => {
        fireEvent.click(screen.getByText('Edit'));
    
        const primaryDropOffInput = screen.getByDisplayValue('Jane Doe');
        fireEvent.change(primaryDropOffInput, { target: { value: 'Jane Smith' } });
        expect(primaryDropOffInput.value).toBe('Jane Smith');
    });
    // test to allow editing children
    test('allows editing children', () => {
        fireEvent.click(screen.getByText('Edit'));
    
        const childrenInput = screen.getByDisplayValue('[{"childName": "Child 1", "childAge": 5, "dropoffSchedule": []}]');
        fireEvent.change(childrenInput, { target: { value: '[{"childName": "Child 1", "childAge": 5, "dropoffSchedule": []}, {"childName": "Child 2", "childAge": 3, "dropoffSchedule": []}]' } });
        expect(childrenInput.value).toBe('[{"childName": "Child 1", "childAge": 5, "dropoffSchedule": []}, {"childName": "Child 2", "childAge": 3, "dropoffSchedule": []}]');
    });
    
    // test to allow editing alternate contacts
    test('allows editing alternate contacts', () => {
        fireEvent.click(screen.getByText('Edit'));
    
        const alternateContactsInput = screen.getByDisplayValue('[]');
        fireEvent.change(alternateContactsInput, { target: { value: '[{"name": "Jane Doe","email": "j@123.ca", "phone": "1234567890"}]' } });
        expect(alternateContactsInput.value).toBe('[{"name": "Jane Doe","email": "j@123.ca", "phone": "1234567890"}]');
    });

});
