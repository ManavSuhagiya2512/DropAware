import { loginUser, registerUser, handleUpdateProfile } from '../components/functions/Auth';

describe('loginUser', () => {
  it('should return the response data if the request is successful', async () => {
    const credentials = { email: 'test@example.com', password: 'password' };
    const mockResponse = { token: 'abc123' };
    global.fetch = jest.fn().mockResolvedValue({
      ok: true,
      json: jest.fn().mockResolvedValue(mockResponse)
    });

    const result = await loginUser(credentials);

    expect(fetch).toHaveBeenCalledWith('http://tester.1.jtfreelancing.com/api/auth/adminsignin', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(credentials)
    });
    expect(result).toEqual(mockResponse);
  });

  it('should return an error message if the request fails with a 403 status code', async () => {
    const credentials = { email: 'test@example.com', password: 'password' };
    global.fetch = jest.fn().mockResolvedValue({
      ok: false,
      status: 403
    });

    const result = await loginUser(credentials);

    expect(result).toEqual('Your email/password do not match our records. Please try again.');
  });

  // Add more test cases for other status codes and error scenarios
});



describe('handleUpdateProfile', () => {
  it('should make a POST request to the update profile API with the provided email and children', async () => {
    const email = 'test@example.com';
    const children = ['child1', 'child2'];
    global.fetch = jest.fn().mockResolvedValue({
      ok: true
    });

    await handleUpdateProfile(email, children);

    expect(fetch).toHaveBeenCalledWith('/updateProfile', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify({ email, children })
    });
  });

  // Add more test cases for different scenarios
});
