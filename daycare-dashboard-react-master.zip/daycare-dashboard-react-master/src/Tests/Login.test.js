import { render, screen } from '@testing-library/react';
import App from '../App';

test('renders login page  with each element', () => {
  render(<App />);

const header = screen.getByText("Please Log In");
  expect(header).toBeInTheDocument();

const emailLabel = screen.getByText("Email");
  expect(emailLabel).toBeInTheDocument();

const passwordLabels = screen.getAllByText("Password");
  expect(passwordLabels.length).toBeGreaterThan(0);
  
  passwordLabels.forEach((passwordLabel) => {
    expect(passwordLabel).toBeInTheDocument();
  });

const submitButton = screen.getByText("Submit");
  expect(submitButton).toBeInTheDocument();
});


