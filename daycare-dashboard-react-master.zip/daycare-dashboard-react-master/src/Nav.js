import React from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';
import PropTypes from 'prop-types';
import './App.css';
import './index.css';
import Login from './components/login.component';
import Register from './components/register.component';
import Dashboard from './components/dashboard.component';

export default function Navigation({ token, setToken, data, setData }) {

    const logout = () => {
        localStorage.clear();
        setToken(null);
    }
    return (
        <Router>
            <div className="App">
            <nav className="navbar navbar-expand-lg navbar-light fixed-top">
                <div className="container">
                <Link className="navbar-brand" to="/"> Drop Aware Dashboard (DAD)</Link>
                <div className="collapse navbar-collapse" id="navbarTogglerDemo02">
                    <ul className="navbar-nav ml-auto">
                    {token ? (
                        <li className="nav-item">
                        <button className="nav-link" onClick={logout}>
                            Logout
                        </button>
                        </li>
                    ) : (
                        <>
                        <li className="nav-item">
                            <Link className="nav-link" to="/">
                            Login
                            </Link>
                        </li>
                        <li className="nav-item">
                            <Link className="nav-link" to="/register">
                            Register
                            </Link>
                        </li>
                        </>
                    )}
                    </ul>
                </div>
                </div>
            </nav>
            <div className="auth-wrapper">
                <div className="auth-inner">
                <Routes>
                {!token && <Route path="/" element={<Login setToken={setToken} setData={setData} />} />}
                {!data && <Route path="/register" element={<Register setToken={setToken} setData={setData} />} />}
                {token && <Route path="/dashboard" element={<Dashboard data={data} setToken={setToken} />} />}
                </Routes>
                
                </div>
            </div>
            </div>
        </Router>
    );
}
Navigation.propTypes = {
    setToken: PropTypes.func.isRequired,
    setData: PropTypes.func.isRequired,
    token: PropTypes.string,
    data: PropTypes.object
  }