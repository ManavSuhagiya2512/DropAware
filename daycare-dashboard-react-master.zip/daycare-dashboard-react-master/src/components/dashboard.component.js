/* eslint-disable no-unused-vars */
import React, { Component, useState, useEffect, useReducer } from "react";
import {NotificationContainer, NotificationManager} from 'react-notifications';
import { Link } from 'react-router-dom';
import TimePicker from 'react-time-picker';
import PropTypes from 'prop-types';
import 'bootstrap/dist/css/bootstrap.min.css';
import emailjs from '@emailjs/browser';
import Popup from 'reactjs-popup';
import 'reactjs-popup/dist/index.css';

import '../App.css';
import '../index.css';
import sendToAPI from './functions/Auth';
import {FancyNotification} from './notification.component';
import { loginUser } from './functions/Auth';

const Dashboard = ({ data, setToken }) => {
    const [d, setD] = useState(data.allUsers || []);
    const [editableProfiles, setEditableProfiles] = useState(Array(d.length).fill(false));

    // method to refresh dashboard with data from api
    const refreshDashboard = () => {
        const email = localStorage.getItem('email');
        const password = localStorage.getItem('password');
        const data = { email, password };
        const API_URL = 'https://tester.1.jtfreelancing.com/api/auth/adminsignin';
        fetch(API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(data),
        })
        .then(response => response.json())
        .catch(error => {
            console.error(error);
        })
        .then(newData => {
            //console.log(newData.allUsers);
            setD((prevD) => {
                const updatedD = [...newData.allUsers];
                return updatedD;
            });
            console.log(d)
            return newData.allUsers;
        })
        .catch(error => {
            console.error(error);
        });
    }

    // method to reset all child to Checked Out status for each weekday 
    const resetWeeklySchedules = async () => {
        await setD((prevD) => {
          const updatedD = prevD.map((user) => {
            const children = user.children ? JSON.parse(user.children) : [];
            const updatedChildrenArray = children.map((child) => {
              const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {

                return [schedule[0], schedule[1], schedule[2], "Checked Out"];
              });
      
              return {
                ...child,
                dropoffSchedule: updatedDropoffSchedule
              };
            });
      
            return {
              ...user,
              children: JSON.stringify(updatedChildrenArray)
            };
          });
          return updatedD;
        });
      
        await setEditableProfiles((prevEditableProfiles) => {
          const updatedEditableProfiles = prevEditableProfiles.map((user) => {
            let children = user.children ? JSON.parse(user.children) : [];
            let kids = children.map((child) => {
              if (typeof child === 'string') {
                return JSON.parse(child);
              }
              return child;
            });
      
            const updatedChildrenArray = kids.map((child) => {
              const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                return [schedule[0], schedule[1], schedule[2], "Checked Out"];
              });
      
              return {
                ...child,
                dropoffSchedule: updatedDropoffSchedule
              };
            });
      
            return {
              ...user,
              children: updatedChildrenArray
            };
          });
      
          return updatedEditableProfiles;
        });

        // update database with new data + provide notification message
        updateAllUsers(`All children's dropoff status set to Checked Out`);
        refreshDashboard();
    };
    
    // method to email schedule to parent
    const emailSchedule = (index) => {
        const user = d[index];
        const children = JSON.parse(user.children);
        const email = user.email;
        const fullname = user.fullname;
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
        let body = `Hello ${fullname},\n\nHere is your children(s) dropoff schedules for ${today}:\n\n`;
        // loop through user's children, get today's schedule, and add to body
        children.forEach((child) => {
            const dropoffSchedule = child.dropoffSchedule;
            dropoffSchedule.forEach((schedule) => {
                if (schedule[0] === today) {
                    body += `Child Name: ${child.childName}\nDropoff Time: ${schedule[1]}\nDay Off?: ${schedule[2]}\n\n`;
                } else if (today === "Sunday" || today === "Saturday") {
                    body += `No Dropoffs Scheduled for ${today}\nEnjoy your weekend!\n\n`
                }
            });
        });
        const body2 = `\n\nThank you for using Drop Aware!`;
        const body3 = `\n\nPlease do not reply to this email.`;
        const fullBody = body + body2 + body3;
        var templateParams = {
            to_name: fullname,
            message: fullBody,
            to_email: email,
        };
        console.log(fullBody)
        emailjs.send("service_dropaware","template_mqlm9re", templateParams, "KwvJTJOkRoo2gaJYu")
        .then(function(response) {
           console.log('SUCCESS!', response.status, response.text);
           NotificationManager.success('Success!', 'Schedule Sent via Email', 5000);
        }, function(error) {
           console.log('FAILED...', error);
           NotificationManager.error('Error Sending Email', 'Please Try Again.', 5000);
        });

    }

    // method to email schedule to alternate contact
    const emailScheduleToContact = (index, contactIndex) => {
        const user = d[index];
        const children = JSON.parse(user.children);
        const contacts = JSON.parse(user.alternateContacts);
        const contact = contacts[contactIndex];
        const email = contact.contactemail;
        const fullname = contact.contactName;
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
        let body = `A parent has you listed as an alternate contact for daycare drop-off. \n\nHere is the children(s) dropoff schedules for ${today}:\n\n`;
        // loop through user's children, get today's schedule, and add to body
        children.forEach((child) => {
            const dropoffSchedule = child.dropoffSchedule;
            dropoffSchedule.forEach((schedule) => {
                if (schedule[0] === today) {
                    body += `Child Name: ${child.childName}\nDropoff Time: ${schedule[1]}\nDay Off?: ${schedule[2]}\n\n`;
                } else if (today === "Sunday" || today === "Saturday") {
                    body += `No Dropoffs Scheduled for ${today}\nEnjoy your weekend!\n\n`
                }
            });
        });
        const body2 = `\n\nThank you for using Drop Aware!`;
        const body3 = `\n\nPlease do not reply to this email.`;
        const fullBody = body + body2 + body3;
        var templateParams = {
            to_name: fullname,
            message: fullBody,
            to_email: email,
        };
        console.log(fullBody)
        emailjs.send("service_dropaware","template_mqlm9re", templateParams, "KwvJTJOkRoo2gaJYu")
        .then(function(response) {
           console.log('SUCCESS!', response.status, response.text);
           NotificationManager.success('Success!', 'Schedule Sent via Email to Alternate Contact', 5000);
        }, function(error) {
           console.log('FAILED...', error);
           NotificationManager.error('Error Sending Email', 'Please Try Again.', 5000);
        });

    }

    // method to text schedule to parent
    const textSchedule = (index) => {
        // use Twilio to send text message
        const user = d[index];
        const children = JSON.parse(user.children);
        const phone = user.phone;
        const fullname = user.fullname;
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
        let body = `Hello ${fullname},\n\nHere is your children(s) dropoff schedules for ${today}:\n\n`;
        // loop through user's children, get today's schedule, and add to body
        children.forEach((child) => {
            const dropoffSchedule = child.dropoffSchedule;
            dropoffSchedule.forEach((schedule) => {
                if (schedule[0] === today) {
                    body += `Child Name: ${child.childName}\nDropoff Time: ${schedule[1]}\Day Off?: ${schedule[2]}\n\n`;
                } else if (today === "Sunday" || today === "Saturday") {
                    body += `No Dropoffs Scheduled for ${today}\nEnjoy your weekend!\n\n`
                }
            });
        });
        const body2 = `\n\nThank you for using Drop Aware!`;
        const body3 = `\n\nPlease do not reply to this text message.`;
        const fullBody = body + body2 + body3;
        // call middleware api /api/messages 
        try {
            fetch('https://tester.1.jtfreelancing.com/api/messages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    body: fullBody,
                    to: phone
                }),
            })
            .then((res) => res.json())
            .then((data) => {
                console.log(data);
                NotificationManager.success('Success!', 'Schedule Sent via Text Message', 5000);
            })
            .catch((err) => {
                console.log(err);
                NotificationManager.error('Error Sending Text Message', 'Please Try Again Momentarily.', 5000);
            });
        } catch (err) {
            console.log(err);
            NotificationManager.error('Error Sending Text Message', 'Please Try Again Momentarily.', 5000);
        }
    }

    // method to text schedule to alternate contact
    const textScheduleToContact = (index, contactIndex) => {
        // use Twilio to send text message
        const user = d[index];
        const children = JSON.parse(user.children);
        const contacts = JSON.parse(user.alternateContacts);
        const contact = contacts[contactIndex];
        const phone = contact.contactphone;
        const fullname = contact.contactName;
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
        let body = `Hello ${fullname},\n\nHere is your children(s) dropoff schedules for ${today}:\n\n`;
        // loop through user's children, get today's schedule, and add to body
        children.forEach((child) => {
            const dropoffSchedule = child.dropoffSchedule;
            dropoffSchedule.forEach((schedule) => {
                if (schedule[0] === today) {
                    body += `Child Name: ${child.childName}\nDropoff Time: ${schedule[1]}\Day Off?: ${schedule[2]}\n\n`;
                } else if (today === "Sunday" || today === "Saturday") {
                    body += `No Dropoffs Scheduled for ${today}\nEnjoy your weekend!\n\n`
                }
            });
        });
        const body2 = `\n\nThank you for using Drop Aware!`;
        const body3 = `\n\nPlease do not reply to this text message.`;
        const fullBody = body + body2 + body3;
        // call middleware api /api/messages 
        try {
            fetch('https://tester.1.jtfreelancing.com/api/messages', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json',
                },
                body: JSON.stringify({
                    body: fullBody,
                    to: phone
                }),
            })
            .then((res) => res.json())
            .then((data) => {
                console.log(data);
                NotificationManager.success('Success!', 'Schedule Sent via Text Message to Alternate Contact', 5000);
            })
            .catch((err) => {
                console.log(err);
                NotificationManager.error('Error Sending Text Message', 'Please Try Again Momentarily.', 5000);
            });
        } catch (err) {
            console.log(err);
            NotificationManager.error('Error Sending Text Message', 'Please Try Again Momentarily.', 5000);
        }
    }

    // method to check in child for current day
    const CheckInChild = async (index, childIndex) => {
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
        // testing
        // const today = "Monday";
        if (today === "Sunday" || today === "Saturday") {
            NotificationManager.error('Error Checking In Child', 'It\'s the Weekend! No Dropoffs.', 5000);
            return;
        }
        updateProfileAndEditableProfiles(index, childIndex, today);
        handleUpdateProfile(index);

    }
    // method to check in child for current day
    const CheckOutChild = async (index, childIndex) => {
        const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
        // testing
        // const today = "Monday";
        if (today === "Sunday" || today === "Saturday") {
            NotificationManager.error('Error Checking Out Child', 'It\'s the Weekend! No Dropoffs.', 5000);
            return;
        }
        await updateProfileAndEditableProfilesCheckOut(index, childIndex, today);
        await handleUpdateProfile(index);

    }

    const updateProfileAndEditableProfiles = async (index, childIndex, today) => {
        await setD((prevD) => {
            const updatedD = [...prevD];
            let children = JSON.parse(updatedD[index]?.children);
            let updatedChildrenArray = children.map((child, i) => {
                if (i === childIndex) {
                    let updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                        if (schedule[0] === today) {
                            child.dropoffSchedule[3] = "Checked In";
                            return [schedule[0], schedule[1], schedule[2], "Checked In"];       // instead of 0,1,2 index, use descriptive names
                        }
                        // s = schedule
                        return schedule;
                    });
                    return {
                        ...child,
                        dropoffSchedule: updatedDropoffSchedule
                    };
                }
                return child;
            });
            updatedD[index] = {
                ...updatedD[index],
                children: JSON.stringify(updatedChildrenArray)
            };
            console.log("updatedD", updatedD)
            return updatedD;
        });
        await setEditableProfiles((prevEditableProfiles) => {
            const updatedEditableProfiles = [...prevEditableProfiles];
            const children = d[index].children;
            let kids = JSON.parse(children)
            const updatedChildrenArray = kids.map((child) => {
                if (typeof child === 'string') {
                    return JSON.parse(child);
                }
                return child;
            });
            updatedEditableProfiles[index] = {
                ...updatedEditableProfiles[index],
                children: JSON.stringify(updatedChildrenArray.map((child, childIndex) => {
                    return child;
                }))
            };
            console.log(updatedEditableProfiles)
            return updatedEditableProfiles;
        });
        await handleScheduleFieldChange(index, childIndex, today, "status", "Checked In");

    };

    const updateProfileAndEditableProfilesCheckOut = async (index, childIndex, today) => {
        await setD((prevD) => {
            const updatedD = [...prevD];
            let children = JSON.parse(updatedD[index]?.children);
            let updatedChildrenArray = children.map((child, i) => {
                if (i === childIndex) {
                    let updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                        if (schedule[0] === today) {
                            child.dropoffSchedule[3] = "Checked Out";
                            return [schedule[0], schedule[1], schedule[2], "Checked Out"];       // instead of 0,1,2 index, use descriptive names
                        }
                        return schedule;
                    });
                    return {
                        ...child,
                        dropoffSchedule: updatedDropoffSchedule
                    };
                }
                return child;
            });
            updatedD[index] = {
                ...updatedD[index],
                children: JSON.stringify(updatedChildrenArray)
            };
            return updatedD;
        });
        await setEditableProfiles((prevEditableProfiles) => {
            const updatedEditableProfiles = [...prevEditableProfiles];
            const children = d[index].children;
            let kids = JSON.parse(children)
            const updatedChildrenArray = kids.map((child) => {
                if (typeof child === 'string') {
                    return JSON.parse(child);
                }
                return child;
            });
            updatedEditableProfiles[index] = {
                ...updatedEditableProfiles[index],
                children: JSON.stringify(updatedChildrenArray.map((child, childIndex) => {
                    return child;
                }))
            };
            console.log(updatedEditableProfiles)
            return updatedEditableProfiles;
        });
        await handleScheduleFieldChange(index, childIndex, today, "status", "Checked Out");

    };

    const UPDATE_API_URL = 'https://tester.1.jtfreelancing.com/api/auth/updateParentProfile';
    const handleUpdateProfile = (index) => {
        // const updatedProfile = d[index];
        const user = { ...d[index], ...editableProfiles[index] }; // Merge the original user object with the updated fields
        // Remove specific fields from the user object
        delete user.password;
        delete user.createdAt;
        delete user.updatedAt;
        delete user.id;

        console.log("user", user)

        // change children and alternateContacts to proper format before sending
        user.children = JSON.parse(user.children, (key, value) => {
            if (typeof value === 'string') {
                return value.replace(/\\/g, ''); // Remove backslashes before double quotes
            }
            console.log(value)
            return value;
        });
        //user.alternateContacts = JSON.stringify(user.alternateContacts);
        user.alternateContacts = JSON.parse(user.alternateContacts, (key, value) => {
            if (typeof value === 'string') {
                return value.replace(/\\/g, ''); // Remove backslashes before double quotes
            }
            return value;
        });
        fetch(UPDATE_API_URL, {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify(user),
        })
        .then(response => response.json())
        .then(data1 => {
            // Handle the response from the API
            // Update the editableProfiles state if needed
            setEditableProfiles((prevEditableProfiles) => {
                const updatedEditableProfiles = [...prevEditableProfiles];
                updatedEditableProfiles[index] = false; // Set to false to make it non-editable
                return updatedEditableProfiles;
            });

            setD((prevD) => {
                const updatedD = [...prevD];
                updatedD[index] = { ...user, ...prevD[index] };
                return updatedD;
            })
            const updatedAllUsers = data.allUsers.map((prevUser, i) => {
                if (i === index) {
                    return { ...user, ...prevUser }; // Merge the existing user object with the new values
                }
                return prevUser;
            });
            NotificationManager.success('Success!', 'Profile Updated', 5000);
        })
        .catch(error => {
            console.error('Error:', error);
            NotificationManager.error('Error Updating Profile', 'Please Try Again', 5000);
        });
    };

    const handleEditProfile = (index) => {
        setEditableProfiles((prevEditableProfiles) => {
            const updatedEditableProfiles = [...prevEditableProfiles];
            updatedEditableProfiles[index] = true;
            return updatedEditableProfiles;
        });
    };

    // method to handle changes to general profile info (name, phone, etc.)
    const handleFieldChange = (index, field, value) => {
        setEditableProfiles((prevEditableProfiles) => {
            const updatedEditableProfiles = [...prevEditableProfiles];
            updatedEditableProfiles[index] = {
                ...updatedEditableProfiles[index],
                [field]: value
            };
            return updatedEditableProfiles;
        });
        setD((prevD) => {
            const updatedD = [...prevD];
            updatedD[index] = {
              ...updatedD[index],
              [field]: value
            };
            return updatedD;
          });
    };

    // method to handle changes to child's name/age
    const handleChildFieldChange = (index, childI, field, value) => {
        setEditableProfiles((prevEditableProfiles) => {
          const updatedEditableProfiles = [...prevEditableProfiles];
          const children = d[index].children;
          let kids = JSON.parse(children)
          const updatedChildrenArray = kids.map((child) => {
            if (typeof child === 'string') {
              return JSON.parse(child);
            }
            return child;
          });
          updatedEditableProfiles[index] = {
            ...updatedEditableProfiles[index],
            children: JSON.stringify(updatedChildrenArray.map((child, childIndex) => {
              if (childIndex === childI) {
                return {
                  ...child,
                  [field]: value
                };
              }
              return child;
            }))
          };
          console.log(updatedEditableProfiles)
          return updatedEditableProfiles;
        });
      
        setD((prevD) => {
          const updatedD = [...prevD];
          const children = JSON.parse(updatedD[index].children);
          const updatedChildrenArray = children.map((child, childIndex) => {
            if (childIndex === childI) {
              return {
                ...child,
                [field]: value
              };
            }
            return child;
          });
          updatedD[index] = {
            ...updatedD[index],
            children: JSON.stringify(updatedChildrenArray)
          };
          return updatedD;
        });           
    };

    // method to handle changes to child's schedule
    const handleScheduleFieldChange = (index, childI, scheduleArray, field, value) => {
        setEditableProfiles((prevEditableProfiles) => {
          const today = new Date().toLocaleDateString('en-US', { weekday: 'long' });
          const updatedEditableProfiles = [...prevEditableProfiles];
          const children = d[index].children;
          let kids = JSON.parse(children);
          const updatedChildrenArray = kids.map((child) => {
            if (typeof child === 'string') {
              return JSON.parse(child);
            }
            return child;
          });
          updatedEditableProfiles[index] = {
            ...updatedEditableProfiles[index],
            children: JSON.stringify(
              updatedChildrenArray.map((child, childIndex) => {
                if (childIndex === childI) {
                  if (field === "dropoffStatus") {
                    const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                      if (schedule[0] === scheduleArray[0]) {
                        return [schedule[0], schedule[1], value, schedule[3]];
                      }
                      return schedule;
                    });
                    return {
                      ...child,
                      dropoffSchedule: updatedDropoffSchedule
                    };
                  }
                  if (field === "dropoffTime") {
                    const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                        if (schedule[0] === scheduleArray[0]) {
                            return [schedule[0], value, schedule[2], schedule[3]];
                        }
                        return schedule;
                    });
                    return {
                        ...child,
                        dropoffSchedule: updatedDropoffSchedule
                    };
                  }
                  if (field === "status") {
                    const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                        if (schedule[0] === today) {
                            return [schedule[0], schedule[1], schedule[2], value];
                        }
                        return schedule;
                    });
                    return {
                        ...child,
                        dropoffSchedule: updatedDropoffSchedule
                    };
                  }
                }
                return child;
              })
            )
          };
          console.log(updatedEditableProfiles);
          return updatedEditableProfiles;
        });
      
        setD((prevD) => {
            const updatedD = [...prevD];
            const children = JSON.parse(updatedD[index].children);
            const updatedChildrenArray = children.map((child, childIndex) => {
                if (childIndex === childI) {
                    if (field === "dropoffStatus") {
                        const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                            if (schedule[0] === scheduleArray[0]) {
                                return [schedule[0], schedule[1], value, schedule[3]];
                            }
                            return schedule;
                        });
                        return {
                            ...child,
                            dropoffSchedule: updatedDropoffSchedule
                        };
                    }
                    if (field === "dropoffTime") {
                        const updatedDropoffSchedule = child.dropoffSchedule.map((schedule) => {
                        if (schedule[0] === scheduleArray[0]) {
                            return [schedule[0], value, schedule[2], schedule[3]];
                        }
                        return schedule;
                        });
                        return {
                            ...child,
                            dropoffSchedule: updatedDropoffSchedule
                        };
                    }
                }
                return child;
            });
            updatedD[index] = {
                ...updatedD[index],
                children: JSON.stringify(updatedChildrenArray)
            };
            return updatedD;
        });        
    };
    
      // method for onChange alternate contact fields
      const handleContactFieldChange = (index, contactI, field, value) => {
        setEditableProfiles((prevEditableProfiles) => {
          const updatedEditableProfiles = [...prevEditableProfiles];
          const contacts = d[index].alternateContacts;
          let altContacts = JSON.parse(contacts)
          const updatedContactArray = altContacts.map((c) => {
            if (typeof c === 'string') {
              return JSON.parse(c);
            }
            return c;
          });
          updatedEditableProfiles[index] = {
            ...updatedEditableProfiles[index],
            alternateContacts: updatedContactArray.map((contact, contactIndex) => {
              if (contactIndex === contactI) {
                return {
                  ...contact,
                  [field]: value
                };
              }
              return contact;
            })
          };
          console.log(updatedEditableProfiles)
          return updatedEditableProfiles;
        });
      
        setD((prevD) => {
          const updatedD = [...prevD];
          const contacts = JSON.parse(updatedD[index].alternateContacts);
          const updatedContactArray = contacts.map((contact, contactIndex) => {
            if (contactIndex === contactI) {
              return {
                ...contact,
                [field]: value
              };
            }
            return contact;
          });
          updatedD[index] = {
            ...updatedD[index],
            alternateContacts: JSON.stringify(updatedContactArray)
          };
          return updatedD;
        });           
    };

      const cancelEdit = (index) => {
        setEditableProfiles((prevEditableProfiles) => {
            const updatedEditableProfiles = [...prevEditableProfiles];
            updatedEditableProfiles[index] = false;
            return updatedEditableProfiles;
        });
    }
    // method to send email to all users
    const [message, setMessage] = useState("");
    const sendEmailToAll = (message) => {
        for (let i = 0; i < d.length; i++) {
            console.log(d[i]?.email)
            // send email to each user with message
            var templateParams = {
                to_name: d[i]?.fullname,
                to_email: d[i]?.email,
                message: message,
            }
            emailjs.send("service_dropaware","template_mqlm9re", templateParams, "KwvJTJOkRoo2gaJYu")
            .then(function(response) {
               console.log('SUCCESS!', response.status, response.text);
               NotificationManager.success('Success!', 'Your email has been sent to all parents', 5000);
            }, function(error) {
               console.log('FAILED...', error);
               NotificationManager.error('Error Sending Email', 'Please Try Again.', 5000);
            });
        }
        NotificationManager.success('Success!', message, 5000);
        
    }

    // function to update each profile in database
    const updateAllUsers = (message) => {
        for (let i = 0; i < d.length; i++) {
            editableProfiles[i] = false;
            handleUpdateProfile(i);
        }
        NotificationManager.success('Success!', message, 5000);
    }

    const logout = () => {
        localStorage.clear();
        setToken(null);
    }

    const [filteredData, setFilteredData] = useState(d); // not currently functional

      

// FRONTEND

    return (
        <div className="container-fluid">
            <div><NotificationContainer/></div>
            <div className="row">
                <main role="main" className="mainSection">
                    <nav className="navbar navbar-expand-lg navbar-light fixed-top" styles="background-color: #e3f2fd;">
                        <div className="container-fluid">
                            {/* icon */}
                            <a href="/dashboard" className="navbar-brand" to={"/dashboard"}>
                                <img src="/dropaware.png" alt="logo" width="65" height="80" /></a>
                            <h3>Drop Aware Dashboard</h3>
                            <button className="btn btn-dark" onClick={refreshDashboard}>Refresh Dashboard</button>
                            <Popup className="popup" trigger={<button class="btn btn-info"> Bulk Email Parents</button>} position="bottom center">
                                <div class="popup-content">
                                    <h4>Email All Parents</h4>
                                    <textarea
                                        className="form-control"
                                        placeholder="Enter Message"
                                        value={message}
                                        onChange={(e) => setMessage(e.target.value)}
                                    />
                                    <br />
                                    <button id="fullBtn" className="btn btn-success" onClick={() => sendEmailToAll(message)}>Send Email</button>
                                </div>
                            </Popup>
                            <button className="btn btn-warning" onClick={resetWeeklySchedules}>Reset Check-Ins</button>
                            <button className="nav-link" onClick={logout}>
                                Logout
                            </button>
                        </div>
                    </nav>
                    <div className="row justify-content-center mainSection">
                        <div className="col-12">
                            <h2>All Registered Parents</h2>
                            
                            <div className="table-responsive">
                                <table className="table table-striped table-lg">
                                    <thead>
                                        <tr>
                                            <th style={{ width: "2%" }}>Full Name</th>
                                            <th style={{ width: "10%" }}>Email</th>
                                            <th style={{ width: "10%" }}>Phone</th>
                                            <th style={{ width: "10%" }}>Primary Drop-off Person</th>
                                            <th style={{ width: "50%" }}>Children</th>
                                            <th style={{ width: "15%" }}>Alternate Contacts</th>
                                            <th style={{ width: "10%" }}>Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                    {d.map((user, index) => (
                                            <tr key={index}>
                                                <td>
                                                    {!editableProfiles[index] ? (user.fullname) 
                                                    : (<input
                                                        type="text"
                                                        placeholder="John Doe"
                                                        value={d[index]?.fullname}
                                                        onChange={(e) => handleFieldChange(index, 'fullname', e.target.value)}
                                                    />)}
                                                </td>
                                                <td class="shortRow">
                                                    <td>{user.email}</td>
                                                </td>
                                                <td>
                                                    {!editableProfiles[index] ? (user.phone) 
                                                    : (<input
                                                        type="text"
                                                        value={d[index]?.phone || (filteredData[index]?.phone)}
                                                        onChange={(e) => handleFieldChange(index, 'phone', e.target.value)}
                                                    />)}
                                                </td>
                                                <td>
                                                    {!editableProfiles[index] ? (user.primaryDropOffPerson) 
                                                    : (<input
                                                        type="text"
                                                        value={d[index]?.primaryDropOffPerson}
                                                        onChange={(e) => handleFieldChange(index, 'primaryDropOffPerson', e.target.value)}
                                                    />)}
                                                </td>
                                                <td>
                                                    <dl>
                                                        {JSON.parse(user.children).map((child, childIndex) => {
                                                            // eslint-disable-next-line react-hooks/rules-of-hooks
                                                            const [isOpen, setIsOpen] = useState(false);
                                                            // eslint-disable-next-line react-hooks/rules-of-hooks
                                                            const [childName, setChildName] = useState(child.childName);
                                                            // eslint-disable-next-line react-hooks/rules-of-hooks
                                                            const [childAge, setChildAge] = useState(child.childAge);
                                                            return (
                                                                <React.Fragment key={childIndex}>
                                                                    <dt
                                                                    style={{
                                                                        fontSize: "20px",
                                                                        backgroundColor: "lightblue",
                                                                        borderRadius: "10px",
                                                                        padding: "10px",
                                                                        marginBottom: "5%",
                                                                        cursor: "pointer",
                                                                    }}
                                                                    onClick={() => setIsOpen(!isOpen)}>
                                                                        <button className="btn btn-info" onClick={() => {CheckInChild(index, childIndex);}}>Check-In Child</button>
                                                                        <button className="btn btn-danger" onClick={() => {CheckOutChild(index, childIndex);}}>Check-Out Child</button>
                                                                        {!editableProfiles[index] ? 
                                                                        (<div>Name:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{child.childName}
                                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                            Age:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;{child.childAge}
                                                                            &nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;
                                                                        </div>)
                                                                        : (
                                                                            <><br/>

                                                                            Name:&nbsp;
                                                                            <input type="text"
                                                                                    value={ filteredData[index]?.children[childIndex].childName || childName}
                                                                                    onChange={(e) => {
                                                                                        handleChildFieldChange(index, childIndex, "childName", e.target.value);
                                                                                        setChildName(e.target.value)
                                                                                    }
                                                                            }/>

                                                                            {/* <input type="text" value={child.childName} onChange={(e) => handleFieldChange(index, 'child.childName ', e.target.value)} /> */}
                                                                            <br />
                                                                            Age: &nbsp;&nbsp;&nbsp;&nbsp;
                                                                            <input type="number"
                                                                                    value={ filteredData[index]?.children[childIndex].childAge || childAge}
                                                                                    onChange={(e) => {
                                                                                        handleChildFieldChange(index, childIndex, "childAge", e.target.value);
                                                                                        setChildAge(e.target.value)
                                                                                    }
                                                                            }/>
                                                                            </>
                                                                        )}
                                                                        
                                                                    </dt>

                                                                    {isOpen && (
                                                                        <>
                                                                            <dt style={{ fontSize: "16px" }}>Schedule</dt>
                                                                            {child.dropoffSchedule.map((schedule, scheduleIndex) => (
                                                                                <dd key={scheduleIndex}>
                                                                                    <table>
                                                                                        <thead>
                                                                                            <th style={{ width: "25%" }}>Day</th>
                                                                                            <th style={{ width: "25%" }}>Time</th>
                                                                                            <th style={{ width: "25%" }}>Day Off?</th>
                                                                                            <th style={{ width: "25%", textAlign: "center" }}>Status</th>
                                                                                        </thead>
                                                                                        <tbody>
                                                                                            <td>
                                                                                                {schedule[0]} {/* Day of week: NON-EDITABLE */}
                                                                                            </td>
                                                                                            <td>
                                                                                            {!editableProfiles[index] ? (
                                                                                                <p>{schedule[1]}</p>
                                                                                            ) : (
                                                                                                <input type="text"
                                                                                                value={schedule[1]}
                                                                                                onChange={(e) => {
                                                                                                    handleScheduleFieldChange(index, childIndex, schedule, 'dropoffTime', e.target.value);
                                                                                                }}
                                                                                                />
                                                                                            )}
                                                                                            </td>
                                                                                            <td>
                                                                                                {/* {schedule[2]} Dropoff status (yes/no) */}
                                                                                                {!editableProfiles[index] ? (schedule[2]) : (
                                                                                                <>
                                                                                                <input
                                                                                                    type="text"
                                                                                                    value={schedule[2]}
                                                                                                    onChange={(e) => (
                                                                                                        handleScheduleFieldChange(index, childIndex, schedule, 'dropoffStatus', e.target.value),
                                                                                                        schedule[2] = e.target.value
                                                                                                )}/>
                                                                                                </>
                                                                                                )}
                                                                                            </td>
                                                                                            <td style={{
                                                                                                backgroundColor: schedule[3] === "Checked In" ? "#4AA325" : "red",
                                                                                                color: "white",
                                                                                                borderRadius: "10px",
                                                                                                padding: "5px",
                                                                                                textAlign: "center",
                                                                                            }}>{schedule[3]}</td>
                                                                                        </tbody>
                                                                                    </table>
                                                                                </dd>
                                                                                
                                                                            ))}
                                                                            <dd>

                                                                            </dd>
                                                                        </>
                                                                    )}
                                                                </React.Fragment>
                                                            );
                                                        })}
                                                    </dl>
                                                </td>
                                                <td class="shortRow">
                                                    <dl>
                                                        {JSON.parse(user.alternateContacts).map((contact, contactIndex) => (
                                                            <React.Fragment key={contactIndex}>
                                                                
                                                                <dt style={{ fontSize: "16px" }}>Name:</dt>
                                                                <dd>
                                                                {!editableProfiles[index] ? (<p>{contact.contactName}</p>) 
                                                                : (<input
                                                                    type="text"
                                                                    value={contact.contactName}
                                                                    onChange={(e) => handleContactFieldChange(index, contactIndex, 'contactName', e.target.value)
                                                                }/>)}
                                                                </dd>
                                                                <dt style={{ fontSize: "16px" }}>Email:</dt>
                                                                <dd> 
                                                                {!editableProfiles[index] ? (<p>{contact.contactemail}</p>) 
                                                                : (<input
                                                                    type="email"
                                                                    value={contact.contactemail}
                                                                    onChange={(e) => handleContactFieldChange(index, contactIndex, 'contactemail', e.target.value)
                                                                }/>)}
                                                                </dd>
                                                                <dt style={{ fontSize: "16px" }}>Phone:</dt>
                                                                <dd>
                                                                {!editableProfiles[index] ? (<p>{contact.contactphone}</p>) 
                                                                : (<input
                                                                    type="text"
                                                                    value={contact.contactphone}
                                                                    onChange={(e) => handleContactFieldChange(index, contactIndex, 'contactphone', e.target.value)
                                                                }/>)}
                                                                </dd>
                                                                <dd>
                                                                <button id="fullBtn" className="btn btn-outline-dark" onClick={() => emailScheduleToContact(index, contactIndex)}>Email Schedule to {contact.contactName}</button>
                                                                <button id="fullBtn" className="btn btn-outline-success" onClick={() => textScheduleToContact(index, contactIndex)}>Text Schedule to {contact.contactName}</button></dd>
                                                            </React.Fragment>
                                ))}
                                                    </dl>
                                                    {/* <button type="submit" class="btn btn-primary">+ Add New Contact</button> */}
                                                </td>
                                                <td class="longRow">
                                                    {!editableProfiles[index] ? (
                                                        <>
                                                        <button class="btn btn-dark" id="fullBtn" onClick={() => handleEditProfile(index)}>Edit</button>
                                                        <br />
                                                        <button class="btn btn-outline-dark" onClick={() => emailSchedule(index)}>Email Schedule to {d[index]?.fullname}</button>
                                                        <br />
                                                        <button class="btn btn-outline-success" onClick={() => textSchedule(index)}>Text Schedule to {d[index]?.fullname}</button>
                                                        </>
                                                    ) : (<div>
                                                        <button class="btn btn-success" onClick={() => handleUpdateProfile(index)}>Save</button><br /><br />
                                                        <button class="btn btn-danger" onClick={() => cancelEdit(index)}>Cancel</button>
                                                    </div>)}
                                                </td>
                                            </tr>
                                        ))
                                        }
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </main>
            </div>
        </div>
    );
}

Dashboard.propTypes = {
    data: PropTypes.object.isRequired,
    setToken: PropTypes.func.isRequired
}

export default Dashboard