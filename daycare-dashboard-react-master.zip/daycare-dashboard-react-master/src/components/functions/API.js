const UPDATE_API_URL = 'https://tester.1.jtfreelancing.com/api/auth/updateParentProfile';
const EXPO_PUSH_API_URL = 'https://exp.host/--/api/v2/push/send';


export const sendToAPI = (user, message) => {
    // Make the API call to update the backend with the data
    fetch(UPDATE_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(user),
    })
      .then(response => response.json())
      .then(responseData => {
        // Handle the response from the API
        console.log(responseData);
        alert(message);
      })
      .catch(error => {
        console.error('Error:', error);
        alert('Error updating data. Please try again.');
      });
  };

  export const sendPushNotification = (expoPushToken, title, message) => {
    // Make the API call to update the backend with the data
    fetch(EXPO_PUSH_API_URL, {
      method: 'POST',
      headers: {
        Accept: 'application/json',
        'Accept-encoding': 'gzip, deflate',
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({
        to: expoPushToken,
        sound: 'default',
        title: title,
        body: message,
      }),
    })
      .then(response => response.json())
      .then(responseData => {
        // Handle the response from the API
        console.log(responseData);
      })
      .catch(error => {
        console.error('Error:', error);
      });
  }
  