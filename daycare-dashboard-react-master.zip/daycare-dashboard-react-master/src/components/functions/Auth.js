import React, { useState } from 'react';
import PropTypes from 'prop-types';

const LOGIN_API_URL = 'https://tester.1.jtfreelancing.com/api/auth/adminsignin';
const REGISTER_API_URL = 'https://tester.1.jtfreelancing.com/api/auth/adminsignup';
const UPDATE_API_URL = 'https://tester.1.jtfreelancing.com/api/auth/updateProfile';

export async function loginUser(credentials) {
 return fetch(LOGIN_API_URL, {
   method: 'POST',
   headers: {
     'Content-Type': 'application/json'
   },
   body: JSON.stringify(credentials)
 })
   .then(data => {
        if (data.ok) {
            return data.json()
        } else if (data.status === 403 || data.status === 404 || data.status === 400 || data.status === 401 || data.status === 500) {
            return "Your email/password do not match our records. Please try again."
        }
   })
}

export async function registerUser(credentials) {
    return fetch(REGISTER_API_URL, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json'
      },
      body: JSON.stringify(credentials)
    })
    .then(data => {
        if (data.ok) {
            return data.json()
        } else if (data.status === 403 || data.status === 404 || data.status === 400 || data.status === 401 || data.status === 500) {
            return "Your email/password do not match our records. Please try again."
        }
    })
}

export default function generateToken() {
    const rand = () => {
    return Math.random().toString(36).substr(2);
    };
    
    const token = () => {
    return rand() + rand();
    };
    
    console.log(token());
    return token();
}