

export const formatTimeForInput = (timeString) => {
    const [time, period] = timeString.split(' ');
    const [hours, minutes] = time.split(':');
    const formattedTime = `${hours.padStart(2, '0')}:${minutes.padStart(2, '0')}`;
    return period === 'AM' ? formattedTime : add12Hours(formattedTime);
};
  
export const add12Hours = (time) => {
    const [hours, minutes] = time.split(':');
    const parsedHours = parseInt(hours, 10);
    const adjustedHours = parsedHours === 12 ? 12 : parsedHours + 12;
    return `${adjustedHours}:${minutes}`;
};
  