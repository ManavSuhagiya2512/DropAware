import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';

import { Navigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import generateToken, { registerUser } from './functions/Auth';

export default function Register({ setToken, setData }) {
    const [email, setEmail] = useState();
    const [adminAccessCode, setAdminAccessCode] = useState();
    const [password, setPassword] = useState();

    const handleSubmit = async e => {
        e.preventDefault();
        const data = await registerUser({
            email,
            adminAccessCode,
            password
        });
        if (data !== "Something went wrong. Please try again." && data!== "Your email/password do not match our records. Please try again." && data !== "Admin Code is invalid. Please try again.") {
            // setToken(token);
            setData(data)
            const token = generateToken()
            setToken(token);
            // alert user that there was an error
        } else {
            alert(data);
        }
    }
  
  return(
    <div className="register-wrapper">
      <h1>Please Register</h1>
      <form onSubmit={handleSubmit}>
        <label>
          <p>Email</p>
          <input type="text" onChange={e => setEmail(e.target.value)} />
        </label>
        <label>
          <p>Admin Code</p>
          <input type="text" onChange={e => setAdminAccessCode(e.target.value)} />
        </label>
        <label>
          <p>Password</p>
          <input type="password" onChange={e => setPassword(e.target.value)} />
        </label>
        <div>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  )
}

Register.propTypes = {
  setToken: PropTypes.func.isRequired,
  setData: PropTypes.func.isRequired
}