import React, { useState, useRef, useEffect, useMemo, useCallback} from 'react';
import { createRoot } from 'react-dom/client';
import { AgGridReact } from 'ag-grid-react'; // the AG Grid React Component

import 'ag-grid-community/styles/ag-grid.css'; // Core grid CSS, always needed
import 'ag-grid-community/styles/ag-theme-alpine.css'; // Optional theme CSS


export default function Table({ data }) {
  const gridRef = useRef();
  const [rowData, setRowData] = useState([]);
  const [childrenRowData, setChildrenRowData] = useState([]);
  const [scheduleRowData, setScheduleRowData] = useState([]);
  const [contactRowData, setContactRowData] = useState([]);

  useEffect(() => {
    if (data) {
      const rows = Object.values(data.allUsers)
      setRowData(rows);
    }
  }, [data]);

  const [columnDefs, setColumnDefs] = useState([
    { field: 'fullname', filter: true },
    { field: 'email', filter: true },
    { field: 'phone', filter: true },
    { field: 'primaryDropOffPerson', filter: true },
    // { field: 'children', filter: true },
    { field: 'alternateContacts', filter: true },
    { field: 'children', cellRenderer: 'ChildrenRenderer' },


    
  ]);

  const defaultColDef = useMemo(() => ({
    sortable: true,
  }));

  const cellClickedListener = useCallback((event) => {
    console.log('cellClicked', event);
  }, []);

  function ChildrenRenderer(params) {
    const children = params.value;
    const childColumnDefs = [
      { field: 'childName', filter: true },
      { field: 'childAge', filter: true },
    ];

    return (
      <div style={{ height: '100%', width: '100%' }}>
        <AgGridReact
          rowData={children}
          columnDefs={childColumnDefs}
          defaultColDef={defaultColDef}
          animateRows={true}
          rowSelection="multiple"
        />
      </div>
    );
  }

  return (
    <div>
      <div className="ag-theme-alpine" style={{ width: 900, height: 500 }}>
        <AgGridReact
          ref={gridRef}
          rowData={rowData}
          columnDefs={columnDefs}
          defaultColDef={defaultColDef}
          animateRows={true}
          rowSelection="multiple"
          onCellClicked={cellClickedListener}
        />
      </div>
    </div>
  );
}

