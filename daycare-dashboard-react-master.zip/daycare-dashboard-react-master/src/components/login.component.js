import React, { useState } from 'react';
import 'bootstrap/dist/css/bootstrap.min.css';
import '../App.css';
import { Navigate } from 'react-router-dom';
import PropTypes from 'prop-types';
import generateToken, { loginUser } from './functions/Auth';

export default function Login({ setToken, setData }) {
  const [email, setEmail] = useState();
  const [password, setPassword] = useState();

  const handleSubmit = async e => {
    e.preventDefault();
    const data = await loginUser({
      email,
      password
    });
    if (data !== "Something went wrong. Please try again." && data !== "Your email/password do not match our records. Please try again.") {
      //setToken(token);
      setData(data)
      const token = generateToken()
      setToken(token);
      localStorage.setItem('token', token);
      localStorage.setItem('email', email);
      localStorage.setItem('password', password);
      // alert user that there was an error
    } else {
      alert(data);
    }
  }
  
  return(
    <div className="login-wrapper">
      <h1>Please Log In</h1>
      <form onSubmit={handleSubmit}>
        <label>
          <p>Email</p>
          <input type="text" onChange={e => setEmail(e.target.value)} />
        </label>
        <label>
          <p>Password</p>
          <input type="password" onChange={e => setPassword(e.target.value)} />
        </label>
        <div>
          <button type="submit">Submit</button>
        </div>
      </form>
    </div>
  )
}

Login.propTypes = {
  setToken: PropTypes.func.isRequired,
  setData: PropTypes.func.isRequired
}


// class Login extends Component {
//   constructor(props) {
//     super(props);
//     this.state = {
//       email: '',
//       password: '',
//       error: null,
//     };
//   }

//   handleInputChange = (event) => {
//     const target = event.target;
//     const value = target.type === 'checkbox' ? target.checked : target.value;
//     const name = target.name;

//     this.setState({
//       [name]: value,
//     });
//   };

//   handleSubmit = (event) => {
//     event.preventDefault();

//     const { email, password } = this.state;

//     const navigate = useNavigate();

//     fetch(LOGIN_URL, {
//       method: 'POST',
//       headers: {
//         'Content-Type': 'application/json',
//       },
//       body: JSON.stringify({ email, password }),
//     })
//       .then((response) => {
//         if (response.ok) {
//           localStorage.isLoggedIn = true;
//           console.log('response', response);
//           console.log(localStorage.isLoggedIn);
//           //this.props.setIsLoggedIn(true);
//           // redirect to the dashboard
//           // history.push('/dashboard');
//           navigate('/dashboard');
//           return <Navigate to="/" replace />;;
//         } else {
//           throw new Error('Something went wrong ...');
//         }
//       })
//       .catch((error) => {
//         this.setState({ error: error.message });
//       });
//   };

//   render() {
//     const { email, password, error } = this.state;

//     return (
//       <div>
//         <div className="container mt-4">
//           <form onSubmit={this.handleSubmit}>
//             <h3>Sign In</h3>
//             {error && <div className="error">{error}</div>}
//             <div className="form-group">
//               <label>Email address</label>
//               <input
//                 type="email"
//                 className="form-control"
//                 placeholder="Enter email"
//                 name="email"
//                 value={email}
//                 onChange={this.handleInputChange}
//               />
//             </div>
//             <div className="form-group">
//               <label>Password</label>
//               <input
//                 type="password"
//                 className="form-control"
//                 placeholder="Enter password"
//                 name="password"
//                 value={password}
//                 onChange={this.handleInputChange}
//               />
//             </div>
//             <button type="submit" className="btn btn-primary">
//               Submit
//             </button>
//           </form>
//         </div>
//       </div>
//     );
//   }
// }

// export default Login;
