import './App.css';
import './index.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import React, { useState, useMemo } from 'react';
import { BrowserRouter as Router, Routes, Route, Link } from 'react-router-dom';

import Login from './components/login.component';
import Register from './components/register.component';
import Dashboard from './components/dashboard.component';
import Navigation from './Nav';
import Table from './components/table.component';


function App() {
  const [token, setToken] = useState();
  const [data, setData] = useState();

  if (!token) {
    return (<>
      <Navigation token={token} setToken={setToken} data={data} setData={setData} />
    </>)
  }
  if (token) {
    console.log(token);
    return  <>
      <Dashboard data={data} setToken={setToken} />
      </>
  }
  const logout = () => {
    localStorage.clear();
    setToken(null);
  }
}

export default App;
