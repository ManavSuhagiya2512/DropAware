
# DropAware Admin Dashboard

This is a web-app for DropAware, built using React Javascript, HTML5 and CSS3, with a bit of Bootstrap for stying. This dashboard allows daycare administrators to create an account, log in, view all registered parent profiles, including each profile's children and alternate contacts, and update these profiles as well.
## Tech Stack
**Frontend:** HTML5, CSS3

**Logic:** React, Javascript

**Libraries/Frameworks:** HTTPS, CORS, Bootstrap

**Testing:** Jest


## Acknowledgements

  - All code, including designs and logic-components are written by the authors listed in the section below. Use of any code without explicit permission is forbidden. © Git-Er-Done Engineers 2023. All Rights Reserved.

## Authors

- Jaime Tavares [@tavaresjaime00](https://www.github.com/tavaresjaime00)
- Jayan Morgan [@JayanMorgan](https://github.com/JayanMorgan)
- Manav Suhagiya [@ManavSuhagiya2512](https://github.com/ManavSuhagiya2512)


## Deployment

To deploy this project online (to launch live on a domain):
1. Ensure you have web-hosting + domain to use
2. Upload  "Build" folder to web-hosting file manager in its own directory,
3. You may be required to complete extra steps, depending on your hosting provider, to set your preferred domain-name to use the uploaded-folder as its home/root directory. 
Once this has been completed, the website will be Live on your domain.  

